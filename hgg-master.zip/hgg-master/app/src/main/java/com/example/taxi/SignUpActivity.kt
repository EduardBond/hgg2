package com.example.taxi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import java.util.regex.Pattern.compile

class SignUpActivity : AppCompatActivity() {
    lateinit var user_name: EditText
    lateinit var phone_number: EditText
    lateinit var email_reg: EditText
    lateinit var password_reg: EditText
    lateinit var password_reg2: EditText
    lateinit var pattern: String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)
        user_name = findViewById(R.id.name_user)
        phone_number = findViewById(R.id.phone_number)
        email_reg = findViewById(R.id.email_reg)
        password_reg = findViewById(R.id.password_reg)
        password_reg2 = findViewById(R.id.password_reg2)
pattern = (("[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,50}" +
        "\\@" +
        "[a-z][a-z\\-]{0,8}" +
        "(" +
        "\\." +
        "[a-z][a-z\\-]{0,5}" +
        ")+"))
    }
fun EmailValid(email:String) : Boolean{
 return compile(pattern).matcher(email).matches()

}
    fun reg(view: View) {
if(user_name.text.isNotEmpty() &&
        phone_number.text.isNotEmpty() &&
        email_reg.text.isNotEmpty() &&
        password_reg.text.isNotEmpty() &&
        password_reg2.text.isNotEmpty()){
    if (password_reg.text != password_reg2.text){
        val alert = AlertDialog.Builder(this)
            .setTitle("Ошибка входа")
            .setMessage("Пароли не совпадают")
            .setPositiveButton("Ok", null)
            .create()
            .show()
        if(EmailValid(email_reg.text.toString())){

        }
        else {
            val alert = AlertDialog.Builder(this)
                .setTitle("Ошибка Email")
                .setMessage("Заполните поле Email корректно")
                .setPositiveButton("Ok", null)
                .create()
                .show()
        }
    }
    else{}
}
        else {
    val alert = AlertDialog.Builder(this)
        .setTitle("Ошибка входа")
        .setMessage("У вас есть пустые поля")
        .setPositiveButton("Ok", null)
        .create()
        .show()
}
    }
}