package com.example.taxi.net

interface ApiRet {
}