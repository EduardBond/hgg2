package com.example.taxi.net

class MyData {
}